Directories:
  + docs/
    This is where you'll find the assignment 1 handout and information.

  + examples/
    This directory contains a few small examples of MPI programs. The examples
    are uncommented so that the code is more visible and to encourage you to
    figure out the what functions are doing.

  + project/
    This is where you will find the source code for the assignment 1 project.
